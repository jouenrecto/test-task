<?php $__env->startSection('body'); ?>
	<br>


	<div class="col-lg-6">
            <div class="well bs-component">
              <form class="form-horizontal" action="\test3\addedit" method="post" >
              <?php echo e(csrf_field()); ?>

             
                <fieldset>
                  <legend>Legend</legend>
                     <div class="form-group">
                    <label for="inputEmail" class="col-lg-2 control-label">ID</label>
                    <div class="col-lg-10">
                      <input class="form-control" id="id" name="id" placeholder="ID" type="text">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputEmail" class="col-lg-2 control-label">Name</label>
                    <div class="col-lg-10">
                      <input class="form-control" id="name" name="name" placeholder="Name" type="text">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputPassword" class="col-lg-2 control-label">User Type</label>
                    <div class="col-lg-10">
                      <input class="form-control" id="userType" name="userType" placeholder="user type" type="text">
                     </div>
                   </div>
                    <div class="form-group">
                    <label for="inputPassword" class="col-lg-2 control-label">Company ID</label>
                    <div class="col-lg-10">
                      <input class="form-control" id="companyId" name="company_id" placeholder="Company ID" type="text">
                     </div>
                   </div>
                    <div class="form-group">
                    <label for="inputPassword" class="col-lg-2 control-label">Department ID</label>
                    <div class="col-lg-10">
                      <input class="form-control" id="departmentId" name="department_id" placeholder="Department ID" type="text">
                     </div>
                   </div>
                    <div class="form-group">
                    <label for="inputPassword" class="col-lg-2 control-label">Email</label>
                    <div class="col-lg-10">
                      <input class="form-control" id="inputEmail" name="email" placeholder="Email" type="email">
                     </div>
                   </div>
                    <div class="form-group">
                      <label for="inputPassword" class="col-lg-2 control-label">Phone</label>
                      <div class="col-lg-10">
                       <input class="form-control" id="phone" name="phone" placeholder="Phone" type="text">
                      </div>
                     </div>
                       <div class="form-group">
                    <label for="inputPassword" class="col-lg-2 control-label">Mobile</label>
                    <div class="col-lg-10">
                      <input class="form-control" id="mobile" name="mobile" placeholder="Mobile" type="text">
                     </div>
                   </div>
                    <div class="form-group">
                    <label for="inputPassword" class="col-lg-2 control-label">Password</label>
                    <div class="col-lg-10">
                      <input class="form-control" id="password" name="password" placeholder="password" type="password">
                     </div>
                   </div>
                    <br>
                  <div class="form-group">
                    <div class="col-lg-10 col-lg-offset-2">
                      <button type="submit" name = "add" class="btn btn-default">Add</button>
                      <button type="submit" name = "edit" class="btn btn-primary">Edit</button>
                    </div>
                  </div>
                </fieldset>
              </form>
            </div>
          </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>