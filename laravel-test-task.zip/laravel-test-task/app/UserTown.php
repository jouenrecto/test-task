<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserTown extends Model
{
    //
}
