<?php

namespace  App;;


class MaileInterface 
{
    //
}