<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="/css/bootstrap.css">
</head>
<body>
	<div class="container">
		<div class="row">
			<?php $__env->startSection('body'); ?>
				<?php echo $__env->yieldSection(); ?>
		</div>
	</div>
</body>
</html>