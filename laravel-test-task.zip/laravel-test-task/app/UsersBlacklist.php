<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UsersBlacklist extends Model
{
    //
}
