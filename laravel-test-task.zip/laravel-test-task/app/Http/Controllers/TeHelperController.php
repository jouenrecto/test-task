<?php

namespace App\Http\Controllers;

use App\Helpers\TeHelper;
use Illuminate\Http\Request;

class TeHelperController extends Controller
{
    function index() {

    	$helper = new TeHelper();
    	 $data = $helper::willExpireAt(null,null);
    	 echo $data;
    }
}
