<?php

namespace App\Http\Controllers;

use App\Repository\UserRepository;
use Illuminate\Http\Request;

class UserController extends UserRepository
{
	function index() {
		return view('home');
	}

	function addedit(Request $request) {

		if(isset($_POST['add'])) {
			parent::createOrUpdate(null, $request);
		}
		else {
			$id = $request->id;
			parent::createOrUpdate($id, $request);
		}

	}

	function show(){
		return view('home');
	}



}
